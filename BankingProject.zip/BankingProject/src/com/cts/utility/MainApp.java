package com.cts.utility;

import java.util.Date;

import com.cts.banking.entities.Customer;
import com.cts.banking.entities.StockExchange;
import com.cts.dao.BankingManager;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
        Customer customer =new Customer();
        customer.setName("Arjun");
        customer.setDOB(new Date(80,5,5));
        customer.setAddress("Chennai");
        
		StockExchange st =new StockExchange();
		st.setName("NSE");
		st.setCountry("India");
		st.setEstd(new Date(56,1,1));
		st.setEmail("nse@india.com");
		st.setRating(5);
		st.setRoi(5487);
		*/
       boolean status= new BankingManager().mergeData();
        /*if(status)
        	System.out.println("Record Modified....");
        else
        	System.out.println("Error Occurred");*/
	}

}
