package com.cts.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import com.cts.banking.entities.Customer;
import com.cts.banking.entities.StockExchange;

public class BankingManager {

	private static int counter;
	private SessionFactory sessionFactory1;
	private SessionFactory sessionFactory2;
	private Session session;
	private boolean status;
	public BankingManager()
	{
		sessionFactory1 = getFactory();
	}
	public boolean addCustomer(Customer customer)
	{
		
		sessionFactory2 = getFactory();
		if(sessionFactory1.equals(sessionFactory2))
			System.out.println("same");
		else
			
			System.out.println("not same");
		session=sessionFactory1.openSession();
		session.getTransaction().begin();
		try
		{
			session.save(customer);
			session.getTransaction().commit();
			status=true;
		}
		catch(HibernateException hib)
		{
			session.getTransaction().rollback();
		}
		finally
		{
			session.close();
		}
		return status;
	}
	public boolean addStockExchange(StockExchange se)
	{
		
			
			
		session=sessionFactory1.openSession();
		session.getTransaction().begin();
		try
		{
			session.save(se);
			session.getTransaction().commit();
			status=true;
		}
		catch(HibernateException hib)
		{
			session.getTransaction().rollback();
		}
		finally
		{
			session.close();
		}
		return status;
	}
	public boolean mergeData()
	{
		session=sessionFactory1.openSession();
		
        Customer customer1=(Customer) session.get(Customer.class, 2);
        Customer customer2=(Customer) session.get(Customer.class, 3);
		//session.clear();
		//session.close();//object detached and session closed
		customer1.setName("Soma_New456");
		customer2.setName("David_New456");
	
		//session=sessionFactory1.openSession();
		
		//Customer customer1=(Customer) session.get(Customer.class, 2);
		
		
		customer1.setName("Soma_New678");
		customer2.setName("David_New678");
		session=sessionFactory1.openSession();
		session.getTransaction().begin();
		customer1=(Customer) session.get(Customer.class, 2);
		customer1.setName("Soma_New888");
		session.update(customer1);
		session.getTransaction().commit();
        return status;
	}
	
	
	public SessionFactory getFactory() 
	{
		Configuration configuration = new Configuration().configure("com/cts/resources/banking.cfg.xml");
		ServiceRegistryBuilder registry = new ServiceRegistryBuilder();
		registry.applySettings(configuration.getProperties());
		ServiceRegistry serviceRegistry = registry.buildServiceRegistry();
		SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
		 
		 return sessionFactory;
	}
}
